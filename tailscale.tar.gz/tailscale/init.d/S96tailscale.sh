#!/bin/sh

/koolshare/scripts/tailscale_config $1
